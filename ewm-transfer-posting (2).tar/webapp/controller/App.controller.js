sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.wl.ewm.transferposting.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  