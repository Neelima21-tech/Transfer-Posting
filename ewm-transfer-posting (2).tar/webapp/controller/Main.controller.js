sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/FilterOperator",
    'sap/m/MessageItem',
    'sap/m/MessagePopover',
    "sap/ui/core/BusyIndicator"
], function (Controller, Fragment, MessageToast, MessageBox, Filter, JSONModel, FilterOperator, MessageItem, MessagePopover, BusyIndicator) {
    "use strict";
    return Controller.extend("com.wl.ewm.transferposting.controller.Main", {
        onInit: function () {
            var oDatePicker1 = this.getView().byId("datePicker");
            var oCurrentDate = new Date();
            oDatePicker1.setDateValue(oCurrentDate);
            // Msg popover    
            var oMessageTemplate = new MessageItem({
                type: '{local>type}',
                title: '{local>title}',
                activeTitle: "{local>active}",
                description: '{local>description}',
                subtitle: '{local>subtitle}',
                counter: '{local>counter}',
                markupDescription: true
            });
            this._oMessagePopover = new MessagePopover({
                items: {
                    path: 'local>/notifications',
                    template: oMessageTemplate
                },
                activeTitlePress: function () {
                    MessageToast.show('Active title is pressed');
                }
            });
            this.getView().addDependent(this._oMessagePopover);
        },
        // Function to clear the local model's form and material data
        clearLocalModelData: function () {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Clear the form data by setting it to an empty object
            oModel.setProperty("/formData", {});
            // Clear the material data by setting it to an empty array
            oModel.setProperty("/materialdata", []);
            // Refresh the model to update the bindings
            oModel.refresh(true);
        },
        onPlantChange: function (oEvent) {
            var sPath = oEvent.getSource().getBinding("value").getPath();
            var oModel = this.getView().getModel("local");
            var sValue = oModel.getProperty(sPath);

            if (sPath === "/formData/SrcPlant" || sPath === "/formData/DestPlant") {
                var oDataModel = this.getView().getModel("ZSB_EWM_BATCH");
                var sFieldName = (sPath === "/formData/SrcPlant") ? "/formData/SrcPlantName" : "/formData/DestPlantName";
                var aFilters = [
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sValue)
                ];
                oDataModel.read("/ZEWM_PLANTMATERIAL_CDS", {
                    filters: aFilters,
                    success: function (oData) {
                        if (oData.results && oData.results.length > 0) {
                            oModel.setProperty(sFieldName, oData.results[0].PlantName || "");
                        } else {
                            oModel.setProperty(sFieldName, "");
                        }
                        oModel.refresh(true);
                    },
                    error: function (oError) {
                        console.error("Error fetching data:", oError);
                        sap.m.MessageToast.show("Failed to fetch plant description");
                    }
                });
            }
        },
        // Validate source plant and initialize transfer dialog
        onSloc: function () {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Get the form data from the local model
            var oData = oModel.getProperty("/formData");
            // Check if the source plant is provided
            if (!oData.SrcPlant) {
                // Show a message toast if the source plant is missing
                var oBundle = this.getView().getModel("i18n").getResourceBundle();
                var sMessage = oBundle.getText("requiredFieldsMessage");
                MessageToast.show(sMessage);
            }
            else {
                // Clear local model data
                this.clearLocalModelData(); // Clear local model data
                // Set the source plant in the form data
                oModel.setProperty("/formData/SrcPlant", oData.SrcPlant);
                // Set the goods movement type to "311" for storage location transfer
                oModel.setProperty("/GoodsMovementType", "311");
                oModel.setProperty("/formData/PostingDate", this.byId("datePicker").getValue());
                // Get the dialog title dynamically from the model
                var sTitle = oModel.getProperty("/dialogTitles/betweenStorageLocations") || "Transfer Between Storage Locations";
                this._openDialog(sTitle, false);
            }
        },
        // Handle material-to-material transfer
        onMaterial: function () {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Get the form data from the local model
            var oData = oModel.getProperty("/formData");
            // Check if the source plant is provided
            if (!oData.SrcPlant) {
                // Show a message toast if the source plant is missing
                var oBundle = this.getView().getModel("i18n").getResourceBundle();
                var sMessage = oBundle.getText("requiredFieldsMessage");
                MessageToast.show(sMessage);
            } else {
                // Clear local model data
                this.clearLocalModelData(); // Clear local model data
                // Set the source plant in the form data
                oModel.setProperty("/formData/SrcPlant", oData.SrcPlant);
                // Set the goods movement type to "309" for material-to-material transfer
                oModel.setProperty("/GoodsMovementType", "309");
                oModel.setProperty("/formData/PostingDate", this.byId("datePicker").getValue());
                var sTitle = oModel.getProperty("/dialogTitles/materialToMaterial") || "Transfer Material to Material";
                // Open the dialog with the dynamically fetched title
                this._openDialog(sTitle, true);
            }
        },
        // Open storage dialog
        _openDialog: function (title) {
            // Get the current view
            var myView = this.getView();
            // Get the storage dialog by its ID from the view
            var oDialog = myView.byId("storageDialog");
            // Check if the dialog already exists
            if (!oDialog) {
                // If the dialog does not exist, load the fragment
                Fragment.load({
                    id: myView.getId(), // Set the ID of the fragment
                    name: "com.wl.ewm.transferposting.fragment.transfer", // Name of the fragment to load
                    controller: this // Set the current controller as the fragment's controller
                }).then(function (oDialog) {
                    var oModel = myView.getModel("local");
                    if (!oModel) {
                        oModel = new JSONModel({
                            dialogTitle: title // Initial dialog title
                        });
                        myView.setModel(oModel, "local");
                    } else {
                        oModel.setProperty("/dialogTitle", title); // Update dialog title dynamically
                    }
                    // Add the dialog as a dependent of the view
                    myView.addDependent(oDialog);
                    //add msg popover
                    myView.byId("notificationonBtn").addDependent(myView.getController()._oMessagePopover);
                    // Fetch and set the plant description
                    myView.getController().onPlantChange({ getSource: function () { return myView.byId("idplant1"); } });
                    // Open the dialog
                    oDialog.open();
                }).catch(function (error) {
                    // Log an error message if the fragment loading fails
                    console.error("Fragment loading failed:", error);
                });
            } else {
                // If the dialog already exists, open it directly
                var oModel = myView.getModel("local");
                if (oModel) {
                    oModel.setProperty("/dialogTitle", title); // Update title dynamically
                }
                // Fetch and set the plant description
                this.onPlantChange({ getSource: function () { return this.byId("idplant1"); }.bind(this) });
                oDialog.open();
            }
        },
        // Function to close the storage dialog
        onpresscancel: function () {
            // Close the storage dialog
            this.getView().byId("storageDialog").close();
        },
        // Function to handle source plant storage location selection
        onSrcPressSloc: function () {
            let oLocalModel = this.getView().getModel("local");
            // Set value help selection field to "sloc"
            oLocalModel.setProperty("/valuehelpSelection/field", "sloc");
            // Set value help selection type to "src"
            oLocalModel.setProperty("/valuehelpSelection/type", "src");
            // Get the user's selected plant
            var userPlant = oLocalModel.getProperty("/formData/SrcPlant");
            // Open the value help dialog for plant selection
            this._openValueHelpDialog("Plant");
            // Filter the plant table based on the user's selected plant
            this._filterPlantTable(userPlant, null, this.getView());
            // Refresh the local model to ensure bindings are updated
            oLocalModel.refresh(true);
        },
        // Function to set description to sloc when sloc value is changed
        onFieldChange: function (oEvent) {
            var sPath = oEvent.getSource().getBinding("value").getPath();
            var oModel = this.getView().getModel("local");
            var sValue = oModel.getProperty(sPath); // Correctly retrieve the value from the model
            var oDataModel = this.getView().getModel("ZSB_EWM_BATCH");
            var sPlant = oModel.getProperty("/formData/SrcPlant");
            var aFilters = [
                new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sValue)
            ];
            oDataModel.read("/ZEWM_PLANTMATERIAL_CDS", {
                filters: aFilters,
                success: function (oData) {
                    if (oData.results && oData.results.length > 0) {
                        if (sPath === '/formData/SrcSLOC') {
                            oModel.setProperty("/formData/SrcSlocDescription", oData.results[0].StorageLocationDescription || "");
                        } else if (sPath === '/formData/DestSLOC') {
                            oModel.setProperty("/formData/DestSlocDescription", oData.results[0].StorageLocationDescription || "");
                        }
                    } else {
                        if (sPath === '/formData/SrcSLOC') {
                            oModel.setProperty("/formData/SrcSlocDescription", "");
                        } else if (sPath === '/formData/DestSLOC') {
                            oModel.setProperty("/formData/DestSlocDescription", "");
                        }
                    }
                    oModel.refresh(true);
                },
                error: function (oError) {
                    console.error("Error fetching data:", oError);
                    MessageToast.show("Invalid data");
                }
            });
        },
        //Function to set description to material when material value is changed
        onMatValChange: function (oEvent) {
            var sPath = oEvent.getSource().getBindingContext("local").getPath();
            var oModel = this.getView().getModel("local");
            var sValue = oModel.getProperty(sPath + "/Material"); // Correctly retrieve the value from the model
            var oDataModel = this.getView().getModel("ZSB_EWM_BATCH");
            // Filters for fetching plant and material-specific data
            var aFilters = [
                new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, oModel.getProperty("/formData/SrcPlant")),
                new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, oModel.getProperty("/formData/SrcSLOC")),
                new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sValue)
            ];
            oModel.setProperty(sPath + "/Dest_Material", sValue);
            // Read operation to fetch plant material data
            oDataModel.read("/ZEWM_PLANTMATERIAL_CDS", {
                filters: aFilters,
                success: function (oData) {
                    if (oData.results && oData.results.length > 0) {
                        oModel.setProperty(sPath + "/description", oData.results[0].ProductDescription || "");
                    } else {
                        oModel.setProperty(sPath + "/description", "");
                    }
                    oModel.refresh(true);
                },
                error: function (oError) {
                    console.error("Error fetching data:", oError);
                    MessageToast.show("Invalid data");
                }
            });
            // Fetch and set Base Unit (UOM) from API_PRODUCT_SRV model
            var oProductModel = this.getView().getModel("API_PRODUCT_SRV");
            var sPlant = oModel.getProperty("/formData/SrcPlant");
            var sProduct = sValue;
            var aProductFilters = [
                new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sProduct)
            ];
            // Read the product plant information with filters
            oProductModel.read("/A_ProductPlant", {
                filters: aProductFilters,
                success: function (oData) {
                    if (oData.results && oData.results.length > 0) {
                        // Set the base unit of measure (UOM) to the local model
                        var oProductInfo = oData.results[0];
                        var sBaseUnit = oProductInfo.BaseUnit;
                        oModel.setProperty(sPath + "/BaseUnit", sBaseUnit);
                    } else {
                        console.error("No product information found for the given plant and product.");
                        oModel.setProperty(sPath + "/BaseUnit", "");
                    }
                    oModel.refresh(true); // Refresh the model to reflect changes in UI
                }.bind(this),
                error: function (oError) {
                    console.error("Error fetching product information:", oError);
                }
            });
        },
        // Function to handle destination plant storage location selection
        onDestPressSloc: function () {
            let oLocalModel = this.getView().getModel("local");
            // Set value help selection field to "sloc"
            oLocalModel.setProperty("/valuehelpSelection/field", "sloc");
            // Set value help selection type to "dest"
            oLocalModel.setProperty("/valuehelpSelection/type", "dest");
            // Get the user's selected plant
            var userPlant = oLocalModel.getProperty("/formData/SrcPlant");
            // Open the value help dialog for plant selection
            this._openValueHelpDialog("Plant");
            // Filter the plant table based on the user's selected plant
            this._filterPlantTable(userPlant, null, this.getView());
            // Refresh the local model to ensure bindings are updated
            oLocalModel.refresh(true);
        },
        // Function to handle source plant material selection
        onSrcPressMat: function (oEvent) {
            let selectedData = this.getView().getModel("local");
            // Set value help selection field to "Mat"
            selectedData.setProperty("/valuehelpSelection/field", "Mat");
            // Set value help selection type to "src"
            selectedData.setProperty("/valuehelpSelection/type", "src");
            // Open the value help dialog for plant selection
            this._openValueHelpDialog("Plant");
            // Get the input field triggering the event
            var oInput = oEvent.getSource();
            // Get the binding context for the local model
            var oContext = oInput.getBindingContext("local");
            // Set the path for value help selection in the local model
            selectedData.setProperty("/valuehelpSelection/path", oContext.getPath());
            // Get user-entered plant and storage location values
            var userPlant = this.getView().byId("idplant1").getValue();
            var userSLOC = this.getView().byId("idsloc").getValue();
            // Filter the plant table based on user-entered plant and storage location
            this._filterPlantTable(userPlant, userSLOC, "Material");
        },
        // Function to filter the plant table based on plant and storage location
        _filterPlantTable: function (plant, sloc) {
            // Initialize an array to store filters
            var aFilters = [];
            // Add filter for plant if it exists
            if (plant) {
                aFilters.push(new Filter("Plant", FilterOperator.EQ, plant));
            }
            // Add filters for plant and storage location if they exist
            if (sloc) {
                // Filter by plant
                aFilters.push(new Filter("Plant", FilterOperator.EQ, plant));
                // Filter by storage location
                aFilters.push(new Filter("StorageLocation", FilterOperator.EQ, sloc));
            }
            // Get the reference to the plant table
            var oTable = this.getView().byId("plantTable");
            if (oTable) {
                // Get the binding for the table items
                var oBinding = oTable.getBinding("items");
                // Apply filters to the table binding
                oBinding.filter(new Filter(aFilters, true), "Application");
            }
        },
        // Function to handle confirmation action on value help dialog selection
        onpressOk: function () {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Get the selected row data from the model
            var oSelectedData = oModel.getProperty("/selectedRowData");
            // Get the field and type from the value help selection
            var oField = oModel.getProperty("/valuehelpSelection/field");
            var oType = oModel.getProperty("/valuehelpSelection/type");
            // Switch case to handle different fields and types
            switch (true) {
                case oField === "sloc" && oType === "src":
                    // Set the source storage location and description
                    oModel.setProperty("/formData/SrcSLOC", oSelectedData.StorageLocation);
                    oModel.setProperty("/formData/SrcSlocDescription", oSelectedData.StorageLocationDescription);
                    break;
                case oField === "sloc" && oType === "dest":
                    // Set the destination storage location and description
                    oModel.setProperty("/formData/DestSLOC", oSelectedData.StorageLocation);
                    oModel.setProperty("/formData/DestSlocDescription", oSelectedData.StorageLocationDescription);
                    break;
                case oField === "Mat" && oType === "src":
                    // Set the material, product description, and destination material
                    oModel.setProperty(oModel.getProperty("/valuehelpSelection/path") + "/Material", oSelectedData.Material);
                    oModel.setProperty(oModel.getProperty("/valuehelpSelection/path") + "/description", oSelectedData.ProductDescription);
                    oModel.setProperty(oModel.getProperty("/valuehelpSelection/path") + "/Dest_Material", oSelectedData.Material);
                    // Assuming 'Material' contains the product ID
                    var sProduct = oSelectedData.Material;
                    var sPlant = oModel.getProperty("/formData/SrcPlant");
                    // Get the API model for product service
                    var oDataModel = this.getView().getModel("API_PRODUCT_SRV");
                    // Create filters for plant and product
                    var aFilters = [
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sProduct)
                    ];
                    // Read the product plant information with filters
                    oDataModel.read("/A_ProductPlant", {
                        filters: aFilters,
                        success: function (oData) {
                            if (oData.results && oData.results.length > 0) {
                                // Set the base unit of measure (UOM) to the local model
                                var oProductInfo = oData.results[0];
                                var sBaseUnit = oProductInfo.BaseUnit;
                                oModel.setProperty(oModel.getProperty("/valuehelpSelection/path") + "/BaseUnit", sBaseUnit);
                            } else {
                                console.error("No product information found for the given plant and product.");
                            }
                        }.bind(this),
                        error: function (oError) {
                            console.error("Error fetching product information:", oError);
                        }
                    });
                    break;
                default:
                    console.error("Unhandled case:", oField, oType);
                    break;
            }
            // Refresh the model to apply changes
            oModel.refresh(true);
            // Close the dialog with the ID "Plant"
            this.getView().byId("Plant").close();
        },
        // Function to open a value help dialog for plant selection
        _openValueHelpDialog: function (sDialogId) {
            // Get the current view
            var myView = this.getView();
            // Find the dialog by its ID
            var oDialog = myView.byId(sDialogId);
            if (!oDialog) {
                // If the dialog does not exist, load the fragment
                Fragment.load({
                    id: myView.getId(),
                    name: "com.wl.ewm.transferposting.fragment.plant",
                    controller: this
                }).then(function (oDialog) {
                    // Add the dialog as a dependent to the view
                    myView.addDependent(oDialog);
                    // Filter the plant table based on the current value of "idplant1"
                    myView.getController()._filterPlantTable(myView.byId("idplant1").getValue(), null, "StorageLocation");
                    // Clear the search field
                    myView.byId("idsearch").setValue("");
                    // Clear the selectedRowData in the local model
                    var oLocalModel = myView.getModel("local");
                    oLocalModel.setProperty("/selectedRowData", {});
                    // Open the dialog
                    oDialog.open();
                }).catch(function (error) {
                    // Log an error if fragment loading fails
                    console.error("Fragment loading failed:", error);
                });
            } else {
                // Clear filters and table data before opening the dialog
                var oTable = myView.byId("plantTable");
                var oBinding = oTable.getBinding("items");
                oBinding.filter([]);

                // Clear the search field
                this.byId("idsearch").setValue("");
                // Clear the selectedRowData in the local model
                var oLocalModel = myView.getModel("local");
                oLocalModel.setProperty("/selectedRowData", {});
                // Open the dialog
                oDialog.open();
                // Filter the plant table based on the current value of "idplant1"
                this._filterPlantTable(myView.byId("idplant1").getValue(), null, "StorageLocation");
            }
        },
        onMaterialMasterClose: function () {
            var oTable = this.byId("plantTable");
            var aItems = oTable.getItems();
            aItems.forEach(function (oItem) {
                var oRadioButton = oItem.getCells()[5]; // Adjust the index based on the position of the RadioButton in your ColumnListItem
                oRadioButton.setSelected(false);
            });

            // Clear the selectedRowData in the local model
            var oModel = this.getView().getModel("local");
            oModel.setProperty("/selectedRowData", {});
        },
        // Function to close the plant selection dialog
        onpressBack: function () {
            // Close the dialog or popover with the ID "Plant"
            this.getView().byId("Plant").close();
        },
        // Function to handle batch change events and update properties for material-to-material transfers
        onbatchchange: function (oEvent) {
            // Check if the material to material flag is true
            if (this._isMaterialToMaterial) {
                // Get the new value from the event parameters
                var sNewValue = oEvent.getParameter("value");
                // Get the event source (the input field)
                var oSource = oEvent.getSource();
                // Get the binding context of the source
                var oContext = oSource.getBindingContext("local");
                // Get the path to the current item in the model
                var sPath = oContext.getPath();
                // Get the local model from the view
                var oModel = this.getView().getModel("local");
                // Update the SrcBatch property for the current line item
                oModel.setProperty(sPath + "/SrcBatch", sNewValue);
                // Automatically set the Dest_Batch to the new SrcBatch value
                // Adjust this logic if the destination batch should be different
                var sDestBatch = sNewValue; // Default to the new SrcBatch value
                oModel.setProperty(sPath + "/Dest_Batch", sDestBatch);
            }
        },
        // Function to add a new item to the material data list based on current settings
        onNextItem: function () {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Get the entire data object from the model
            var oData = oModel.getProperty("/");
            // Create a new item with default values
            var newItem = {
                Item: (oData.materialdata.length + 1).toString(),
                Material: "",
                SrcBatch: oData.formData.SrcBatch || "",
                Dest_Material: "",
                Dest_Batch: "",
                Qty: "",
                UOM: ""
            };
            // Check if the Goods Movement Type is "309"
            if (oModel.getProperty("/GoodsMovementType") === "309") {
                // Get the index of the last entry in the material data
                var lastIndex = oData.materialdata.length;
                // If there are existing entries
                if (lastIndex) {
                    // Get the last entry from the material data
                    var lastEntry = oModel.getProperty("/materialdata/" + (lastIndex - 1).toString());
                    // Check if the last entry does not have a destination batch
                    if (!lastEntry.Dest_Batch) {
                        // Show a confirmation dialog to create a destination batch
                        MessageBox.confirm("Destination batch is missing, do you want to create a destination batch?", {
                            actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                            onClose: function (oAction) {
                                if (oAction === MessageBox.Action.YES) {
                                    // User chose to create a destination batch, call the API
                                    this._callDestBatchAPI(lastEntry);
                                } else {
                                    // User chose not to create, add the new item without Dest_Batch
                                    oData.materialdata.push(newItem);
                                    oModel.setProperty("/materialdata", oData.materialdata);
                                }
                            }.bind(this)
                        });
                    } else {
                        // Destination batch exists, add the new item
                        oData.materialdata.push(newItem);
                        oModel.setProperty("/materialdata", oData.materialdata);
                    }
                } else {
                    // First entry, simply add the new item
                    oData.materialdata.push(newItem);
                    oModel.setProperty("/materialdata", oData.materialdata);
                }
            } else {
                // For other Goods Movement Types, just add the new item
                oData.materialdata.push(newItem);
                oModel.setProperty("/materialdata", oData.materialdata);
            }
        },
        // Function to handle deletion of an item from the material data list
        handleDelete: function (oEvent) {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Get the current array of material data from the model
            var aItems = oModel.getProperty("/materialdata");
            // Get the item to be deleted from the event parameters
            var oItem = oEvent.getParameter("listItem");
            // Get the binding context path of the item to be deleted
            var sPath = oItem.getBindingContextPath();
            // Extract the index of the item to be deleted from the path
            var iIndex = parseInt(sPath.split("/")[2]);
            // Remove the item from the array
            aItems.splice(iIndex, 1);
            // Recalculate item numbers after deletion
            aItems.forEach(function (item, index) {
                item.Item = (index + 1).toString();
            });
            // Update the model with the modified array
            oModel.setProperty("/materialdata", aItems);
        },
        // function to apply filter as per the inputted search value
        handlebatch: function (oEvent) {
            // Get the search value from the event parameters
            var sSearch = oEvent.getParameter("newValue");
            // Initialize an array to hold the filters
            var aFilters = [];
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Get the field being searched from the local model
            var oField = oModel.getProperty("/valuehelpSelection/field");
            // Check if there is a search value and it is not empty
            if (sSearch && sSearch.length > 0) {
                // Add filters based on the field being searched
                if (oField === "sloc") {
                    // Add filters for plant and storage location
                    aFilters.push(new Filter("Plant", FilterOperator.EQ, oModel.getProperty("/formData/SrcPlant")));
                    aFilters.push(new Filter("StorageLocation", FilterOperator.Contains, sSearch));
                } else if (oField === "Mat") {
                    // Add filters for plant, storage location, and material
                    aFilters.push(new Filter("Plant", FilterOperator.EQ, oModel.getProperty("/formData/SrcPlant")));
                    aFilters.push(new Filter("StorageLocation", FilterOperator.EQ, oModel.getProperty("/formData/SrcSLOC")));
                    aFilters.push(new Filter("Material", FilterOperator.Contains, sSearch));
                }
                // Check if there are filters to apply
                if (aFilters && aFilters.length > 0) {
                    // Get the table by its ID
                    var oTable = this.getView().byId("plantTable");
                    // Get the binding of the items in the table
                    var oBinding = oTable.getBinding("items");
                    // Apply the filters to the table binding
                    oBinding.filter(aFilters, "Application");
                }
            }
        },
        // Function to handle selection events and update selected row data in the local model
        onSelected: function (oEvent) {
            // Get the selected item from the event source, using the binding context of the "ZSB_EWM_BATCH" model
            var oSelectedItem = oEvent.getSource().getBindingContext("ZSB_EWM_BATCH").getObject();
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Assuming you have a radio button bound to a property in your mode
            // Set the selected item data to the "selectedRowData" property in the local model
            oModel.setProperty("/selectedRowData", oSelectedItem);
        },
        // function to form payload for Document Header create
        _formPostinDocPayload: function () {
            var oLocalModel = this.getView().getModel("local");
            var payloadData = {
                "MaterialDocumentHeaderText": oLocalModel.getProperty("/formData/HeaderNotes"),
                "VersionForPrintingSlip": "2",
                "ManualPrintIsTriggered": "",
                "CtrlPostgForExtWhseMgmtSyst": "",
                "GoodsMovementCode": "04",
                "PostingDate": oLocalModel.getProperty("/formData/PostingDate"),
                "to_MaterialDocumentItem": {
                    "results": oLocalModel.getProperty("/materialdata").map(function (item) {
                        return {
                            "Material": item.Material,
                            "Plant": oLocalModel.getProperty("/formData/SrcPlant"),
                            "StorageLocation": oLocalModel.getProperty("/formData/SrcSLOC"),
                            "GoodsMovementType": oLocalModel.getProperty("/GoodsMovementType"),
                            "EntryUnit": item.BaseUnit,
                            "QuantityInEntryUnit": item.Qty.replace(/\s+/g,''),
                            "IssgOrRcvgMaterial": item.Dest_Material,
                            "IssuingOrReceivingPlant": oLocalModel.getProperty("/formData/SrcPlant"),
                            "IssuingOrReceivingStorageLoc": oLocalModel.getProperty("/formData/DestSLOC"),
                            "Batch": item.SrcBatch.replace(/\s+/g,''),
                            "IssgOrRcvgBatch": item.Dest_Batch
                        }
                    })
                }
            };
            return payloadData;
        },
        // Function to call the API for creating a material document and handling success or error responses
        _callDocCreateAPI: function () {
            // Show busy indicator before the API call
            sap.ui.core.BusyIndicator.show(0);
            // Get the API model for material documents
            var oDataModel = this.getView().getModel("API_MATERIAL_DOCUMENT");
            var oModel = this.getView().getModel('local');
            // Form the payload for posting the document
            var oPayload = this._formPostinDocPayload();
            // Create the material document header with the payload
            oDataModel.create("/A_MaterialDocumentHeader", oPayload, {
                // Success handler
                success: function (oData, oHeader) {
                    // Hide busy indicator on success
                    sap.ui.core.BusyIndicator.hide();
                    if(oHeader.data && oHeader.data.MaterialDocument)
                        MessageToast.show("Delivery Document "+oHeader.data.MaterialDocument + " is created.");
                    if (oHeader && oHeader.headers && oHeader.headers["sap-message"])
                        // Show a message toast with the document number on successful creation
                        MessageToast.show(JSON.parse(oHeader.headers["sap-message"]).message);
                    this.clearNotifications();
                    // Clear the local model data after successful post
                    //this.clearLocalModelData();
                }.bind(this),
                // Error handler
                error: function (oError) {
                    // Hide busy indicator on error
                    sap.ui.core.BusyIndicator.hide();
                    // Show an error message box if document creation fails
                    var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
                    MessageBox.error("Error posting document: " + oError.message);
                    oModel.setProperty('/notifications', [
                        {
                            "type": "Error",
                            "title": "Error message",
                            "description": sErrorMessage,
                            "counter": 1
                        }
                    ]);
                }
           
            });
        },
        // Function to handle the posting of material data based on the selected goods movement type
        onPressPost: function () {
            // Get the local model
            var oModel = this.getView().getModel("local");
            // Get the material data from the model
            var oMaterialData = oModel.getProperty("/materialdata");
            // Check if there is material data available
            if (oMaterialData.length > 0) {
                // Handle Goods Movement Type "309"
                if (oModel.getProperty("/GoodsMovementType") === "309") {
                    // Get the last entry in the material data array
                    var lastIndex = oMaterialData.length;
                    var lastEntry = oModel.getProperty("/materialdata/" + (lastIndex - 1).toString());
                    // Check if the last entry has a destination batch
                    if (!lastEntry.Dest_Batch) {
                        // If no destination batch, create one
                        this._createDestBatch(lastEntry);
                    } else {
                        // Otherwise, call the document creation API
                        this._callDocCreateAPI();
                    }
                // Handle Goods Movement Type "311"
             } else if (oModel.getProperty("/GoodsMovementType") === "311") {
                    // Call the document creation API
                    this._callDocCreateAPI();
                }
            }
        },
        // Function to prompt the user to create a destination batch if missing
        _createDestBatch: function (entry) {
            MessageBox.confirm("Destination batch is missing, do you want to create a destination batch?", {
                actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                onClose: function (oAction) {
                    if (oAction === MessageBox.Action.YES) {
                        // User confirmed to create a destination batch
                        this._callDestBatchAPI(entry);
                    } else {
                        // User canceled, do nothing or handle as needed
                        MessageToast.show("Post action canceled. Please enter destination batch.");
                    }
                }.bind(this)
            });
        },
        //api call is working bit output not coming properly
        _callDestBatchAPI: function (oContext) {
            var oDestBatchModel = this.getView().getModel("ZSB_EWM_BATCH");
            var oModel = this.getView().getModel('local');
            this.clearNotifications();
            if (!oContext.Material || !oContext.SrcBatch) {
                    this._addNotification("Error", "Source Batch or Material field cannot be empty.");
                    MessageBox.error("Source Batch or Material field cannot be empty.");
                    return;
                }
            // Show busy indicator before the API call
            sap.ui.core.BusyIndicator.show(0);
            oDestBatchModel.callFunction("/Enter", {
                method: "POST",
                urlParameters: {
                    "Material": oContext.Material,
                    "Plant": this.getView().getModel("local").getProperty("/formData/SrcPlant"),
                    "Batch": oContext.SrcBatch
                },
                success: function (oData, oHeader) {
                    // Hide busy indicator on success
                    sap.ui.core.BusyIndicator.hide();
                    // Update the entry with the returned batch value
                    oContext.Dest_Batch = oData.Batch; // Replace with the actual field name returned by API
                    if (oHeader && oHeader.headers && oHeader.headers["sap-message"]) {
                        // Show a message toast with the document number on successful creation
                        oContext.Dest_Batch = JSON.parse(oHeader.headers["sap-message"]).message;
                        this.getView().getModel("local").refresh(); // Refresh the model to reflect changes
                        MessageToast.show("Destination batch created successfully.");
                    }
                }.bind(this),
                error: function (oError) {
                    // Hide busy indicator on error
                    sap.ui.core.BusyIndicator.hide();
                    var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
                    MessageBox.error("Error in creation destination batch: " + oError.message);
                    oModel.setProperty('/notifications', [
                        {
                            "type": "Error",
                            "title": "Error message",
                            "description": sErrorMessage,
                            "counter": 1
                        }
                    ]);
                }
            });
        },
        _addNotification: function (type, message) {
            var oModel = this.getView().getModel("local");
            var aNotifications = oModel.getProperty("/notifications");
            aNotifications.push({
                type: type,
                title: "Error",
                description: message,
                counter: aNotifications.length + 1 // Assuming you increment counter for each notification
            });
            oModel.setProperty("/notifications", aNotifications);
            oModel.refresh();
        },
        // Function to clear notifications in the local model
        clearNotifications: function () {
            // Get the local model from the view
            var oModel = this.getView().getModel("local");
            // Set an empty array for notifications to clear existing notifications
            oModel.setProperty("/notifications", []);
        },
        // Toggles the visibility of the notification popover when the notification button is pressed.
        handleMessagePopoverPress: function (oEvent) {
            this._oMessagePopover.toggle(oEvent.getSource());
        },

    });
});

