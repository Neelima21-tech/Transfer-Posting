/* global QUnit */

sap.ui.require(["com/sap/ztransferposting/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
